
UI Design

🔵Home Page


![MovieAppImage](https://user-images.githubusercontent.com/66914300/149370624-ca1a7814-44be-4937-86d4-5a810d0f6f93.PNG)




🔵Search Result with modal



![MovieAppImage2](https://user-images.githubusercontent.com/66914300/149370693-3adbc3e0-a108-46c9-a8dc-85660f04821f.PNG)

📌API_URL="https://api.themoviedb.org/3/movie/popular?api_key=<<api_key_here>>"

📌API_IMG="https://image.tmdb.org/t/p/w500/"

📌API_SEARCH="https://api.themoviedb.org/3/search/movie?api_key=<<api_key_here>>&query"
